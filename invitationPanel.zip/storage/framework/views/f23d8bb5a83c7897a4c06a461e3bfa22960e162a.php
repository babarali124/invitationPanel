<?php $__env->startComponent('mail::message'); ?>
# Invitaion

Here it is your access.

<?php $__env->startComponent('mail::panel'); ?>
User Name: <?php echo e($user->username); ?>

<?php echo $__env->renderComponent(); ?>
<?php $__env->startComponent('mail::panel'); ?>
Password: <?php echo e($user->password); ?>

<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>