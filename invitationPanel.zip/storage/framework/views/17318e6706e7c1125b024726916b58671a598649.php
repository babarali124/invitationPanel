<?php $__env->startSection('title'); ?>
Change Charges
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row justify-content-md-center">
	<div class="col-md-6">
		<div class="card">
			<div class="card-header">
				<h4 class="card-title" id="basic-layout-form">Project Info</h4>
				<a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
				<div class="heading-elements">
					<ul class="list-inline mb-0">
						<li><a data-action="collapse"><i class="ft-minus"></i></a></li>
						<li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
						<li><a data-action="expand"><i class="ft-maximize"></i></a></li>
						<li><a data-action="close"><i class="ft-x"></i></a></li>
					</ul>
				</div>
			</div>
			<div class="card-content collapse show">
				<div class="card-body">
					<?php if(Session::has('success')): ?>
					<div class="alert alert-success alert-dismissible">
						<button type="button" class="close" data-dismiss="alert" aria-hidden="true">Ã—</button>
						<?php echo e(Session::get('success')); ?>

					</div>
					<?php endif; ?>
					<?php if(Session::has('error')): ?>
					<div class="alert alert-danger alert-dismissible">
						<button type="button" class="close" data-dismiss="alert" aria-hidden="true">Ã—</button>
						<?php echo e(Session::get('error')); ?>

					</div>
					<?php endif; ?>
					<?php if($errors->any()): ?>
					<div class="alert alert-danger">
						<ul style="margin: 0px;">
							<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li><?php echo e($error); ?></li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
					</div>
					<?php endif; ?>
					<form class="form" action="<?php echo e(route('admin.profile.update')); ?>" method="post">
						<?php echo e(csrf_field()); ?>

						<div class="form-body">
							<div class="row">
								<div class="col-md-12">
									<div class="form-group">
										<label for="projectinput1">Full Name</label>
										<input type="text" id="projectinput1" class="form-control" placeholder="Full Name" name="name" value="<?php echo e(auth()->guard('admin')->user()->name); ?>">
									</div>
								</div>
							</div>
							
							<h4 class="form-section"><i class="la la-paperclip"></i> Change Password</h4>
							<div class="form-group">
								<label for="current_password">Current Password</label>
								<input type="password" class="form-control" id="current_password" placeholder="Current Password" name="current_password" value="" >
							</div>
							<div class="form-group">
								<label for="password">New Password</label>
								<input type="password" class="form-control" id="password" placeholder="New Password" name="new_password" value="" >
							</div>
							<div class="form-group">
								<label for="password_confirmation">Confirm Password</label>
								<input type="password" class="form-control" id="password_confirmation" placeholder="Confirm Password" name="password_confirmation" value="" >
							</div>
							
						</div>
						<div class="form-actions">
							<button type="button" class="btn btn-warning mr-1">
								<i class="ft-x"></i> Cancel
							</button>
							<button type="submit" class="btn btn-primary">
								<i class="la la-check-square-o"></i> Save
							</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>