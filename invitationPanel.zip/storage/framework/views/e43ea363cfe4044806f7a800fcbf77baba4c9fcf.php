<?php $__env->startSection('breadcrumbs'); ?>
<div class="content-header-left col-md-6 col-12 mb-2 breadcrumb-new">
    <div class="row breadcrumbs-top d-inline-block">
        <div class="breadcrumb-wrapper col-12">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a>
                </li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.users.index')); ?>">Manage Users</a>
                </li>
                <li class="breadcrumb-item active">Edit User</li>
            </ol>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section id="basic-form-layouts">
    <div class="row justify-content-md-center">
        <div class="col-md-12">
            <?php if(Session::has('success')): ?>
            <div class="alert alert-success alert-dismissable">
                <?php echo e(Session::get('success')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php endif; ?>
            <?php if(Session::has('error')): ?>
            <div class="alert alert-danger alert-dismissable">
                <?php echo e(Session::get('error')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <ul style="margin: 0;">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <div class="card">
                <form class="form" action="<?php echo e(route('admin.users.update', [$user->id])); ?>" method="POST">
                    <input type="hidden" name="_method" value="put">
                    <?php echo csrf_field(); ?>
                    <div class="card-content">
                        <div class="card-body">
                            <div class="box_general padding_bottom">
                                <div class="header_box version_2">
                                    <h2><i class="ft-user"></i>Update User</h2>
                                </div>
                                <div class="row">
                                    <div class="col-md-8 add_top_30">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="email">Email</label>
                                                    <input type="email" id="email" required value="<?php echo e($user->email); ?>"
                                                        class="form-control" placeholder="E-mail" name="email">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="username">UserName</label>
                                                    <input type="text" id="username" required value="<?php echo e($user->username); ?>"
                                                        class="form-control" placeholder="E-mail" name="username">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="password">New password</label>
                                                    <input type="text" id="password" required value="<?php echo e($user->password); ?>"
                                                        class="form-control" placeholder="New password" name="password">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-actions">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fa fa-check-square-o position-right"></i> Submit
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>