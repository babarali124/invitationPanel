@component('mail::message')
# Invitaion

Here it is your access.

@component('mail::panel')
User Name: {{$user->username}}
@endcomponent
@component('mail::panel')
Password: {{$user->password}}
@endcomponent

Thanks,<br>
{{ config('app.name') }}
@endcomponent