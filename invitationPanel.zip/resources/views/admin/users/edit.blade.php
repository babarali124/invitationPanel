@extends('admin.layouts.app')
@section('breadcrumbs')
<div class="content-header-left col-md-6 col-12 mb-2 breadcrumb-new">
    <div class="row breadcrumbs-top d-inline-block">
        <div class="breadcrumb-wrapper col-12">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a>
                </li>
                <li class="breadcrumb-item"><a href="{{ route('admin.users.index') }}">Manage Users</a>
                </li>
                <li class="breadcrumb-item active">Edit User</li>
            </ol>
        </div>
    </div>
</div>
@endsection
@section('content')
<section id="basic-form-layouts">
    <div class="row justify-content-md-center">
        <div class="col-md-12">
            @if(Session::has('success'))
            <div class="alert alert-success alert-dismissable">
                {{ Session::get('success') }}
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            @endif
            @if(Session::has('error'))
            <div class="alert alert-danger alert-dismissable">
                {{ Session::get('error') }}
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            @endif
            @if ($errors->any())
            <div class="alert alert-danger">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <ul style="margin: 0;">
                    @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
            @endif
            <div class="card">
                <form class="form" action="{{ route('admin.users.update', [$user->id]) }}" method="POST">
                    <input type="hidden" name="_method" value="put">
                    @csrf
                    <div class="card-content">
                        <div class="card-body">
                            <div class="box_general padding_bottom">
                                <div class="header_box version_2">
                                    <h2><i class="ft-user"></i>Update User</h2>
                                </div>
                                <div class="row">
                                    <div class="col-md-8 add_top_30">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="email">Email</label>
                                                    <input type="email" id="email" required value="{{ $user->email }}"
                                                        class="form-control" placeholder="E-mail" name="email">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="username">UserName</label>
                                                    <input type="text" id="username" required value="{{ $user->username }}"
                                                        class="form-control" placeholder="E-mail" name="username">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="password">New password</label>
                                                    <input type="text" id="password" required value="{{ $user->password }}"
                                                        class="form-control" placeholder="New password" name="password">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-actions">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fa fa-check-square-o position-right"></i> Submit
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
@endsection
@push('js')
@endpush