@extends('admin.layouts.app') @push('css')
<link rel="stylesheet" type="text/css" href="{{ asset('app-assets/vendors/css/tables/datatable/datatables.min.css') }}"> 
@endpush 
@section('title')
Users
@endsection
@section('breadcrumbs')
<div class="content-header-left col-md-6 col-12 mb-2 breadcrumb-new">
    <div class="row breadcrumbs-top d-inline-block">
        <div class="breadcrumb-wrapper col-12">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a>
                </li>
                <li class="breadcrumb-item"><a href="{{ route('admin.users.index') }}">Manage Users</a>
                </li>
                <li class="breadcrumb-item active">Users</li>
            </ol>
        </div>
    </div>
</div>
@endsection
 
@section('content')
<section id="configuration">
    <div class="row">
        <div class="col-12">
            @if(Session::has('success'))
            <div class="alert alert-success alert-dismissable">
                <button class="close" data-dismiss="alert"></button> {{ Session::get('success') }}
            </div>
            @endif
            <div class="card">
                <div class="card-header">
                    <a href="{{route('admin.users.create')}}" class="btn  btn-info">Add User</a>
                    <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                    <div class="heading-elements">
                        <ul class="list-inline mb-0">
                            <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                            <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                            <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            <li><a data-action="close"><i class="ft-x"></i></a></li>
                        </ul>
                    </div>
                </div>

                <div class="card-content collapse show">
                    <div class="card-body card-dashboard">
                        <table class="table table-striped table-bordered dataex-html5-selectors">
                            <thead>
                                <tr>
                                    <th>UserName</th>
                                    <th>Email</th>
                                    <th>Password</th>
                                    <th>Send At</th>
                                    <th>Login At</th>
                                    <th>Logout At</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @if(!empty($users)) @foreach($users as $user)
                                <tr>
                                    <td>{{ $user->username }}</td>
                                    <td>{{ $user->email }}</td>
                                    <td>{{ $user->password }}</td>
                                    <td>{{ $user->sent_at }}</td>
                                    <td>{{ $user->login_at }}</td>
                                    <td>{{ $user->logout_at }}</td>
                                    <td>
                                        <a href="{{ route('admin.users.invite',[$user->id]) }}" class="btn btn-info btn-sm">Send
                                            Invite</a>
                                        <a href="{{ route('admin.users.edit',[$user->id]) }}" class="btn  btn-info btn-sm">Edit</a>
                                        <form action="{{ route('admin.users.destroy', $user->id) }}" method="post" style="display: inline-block;" onsubmit="return confirm('are you sure?')">
                                            @csrf {{ method_field('DELETE') }}
                                            <button type="submit" class="btn btn-danger  btn-sm">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                                @endforeach @endif
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>UserName</th>
                                    <th>Email</th>
                                    <th>Password</th>
                                    <th>Send At</th>
                                    <th>Login At</th>
                                    <th>Logout At</th>
                                    <th>Actions</th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection
 @push('js')
<script src="{{ asset('app-assets/vendors/js/tables/datatable/datatables.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('app-assets/vendors/js/tables/datatable/dataTables.buttons.min.js.js') }}" type="text/javascript"></script>
<script src="{{ asset('app-assets/vendors/js/tables/datatable/buttons.bootstrap4.min.js.js') }}" type="text/javascript"></script>
<script src="{{ asset('app-assets/vendors/js/tables/buttons.colVis.min.js.js') }}" type="text/javascript"></script>
<script>
    $('.dataex-html5-selectors').DataTable( {
    dom: 'Bfrtip',
    buttons: [
        
        {
            extend: 'csvHtml5',
            exportOptions: {
                columns: [ 0, ':visible' ]
            }
        },
        {
            extend: 'excelHtml5',
            exportOptions: {
                columns: ':visible'
            }
        },
       
        'colvis'
    ]
} );

</script>
@endpush