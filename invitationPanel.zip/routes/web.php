<?php

Route::get('/', function () {
    return redirect()->route('login');
});
Route::get('/login', 'Admin\AuthController@login')->name('login');
Route::get('/changepassword', 'Admin\AuthController@changePassword')->name('changepassword');
Route::post('/changepassword', 'Admin\AuthController@changePasswordNow')->name('changepassword');
Route::post('/admin/authenticate', 'Admin\AuthController@authenticate')->name('admin.authenticate');

Route::group(['prefix' => 'admin', 'as' => 'admin.', 'middleware' => 'auth:admin', 'namespace' => 'Admin'], function () {
    Route::get('/dashboard', 'DashboardController@index')->name('dashboard');
    Route::post('/profile/update', 'AdminController@updateProfile')->name('profile.update');
    Route::get('/logout', 'AuthController@logout')->name('logout');
    Route::get('/profile', 'AdminController@profile')->name('profile');
    Route::get('/users/invite/{id}', 'UsersController@sendInvite')->name('users.invite');
    Route::resource('/users', 'UsersController');
});
