<?php

namespace App\Http\Controllers\Admin;

use App\User;
use App\Http\Controllers\Controller;

class DashboardController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');
    }

    public function index()
    {
        $users = User::count();
        // $categories = Category::count();
        // $articles = Article::count();
        // $albums = Album::count();
        return view('admin.index', compact('users'));
    }
}
