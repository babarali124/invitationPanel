<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;

class AuthController extends Controller
{
    public function __construct()
    {
    }

    public function login()
    {
        $this->middleware('guest:admin');
        if (auth()->guard('admin')->guest()) {
            return view('admin.auth.login');
        } else {
            return redirect()->intended('admin/dashboard');
        }
    }

    public function authenticate(Request $request)
    {
        $validator = $this->validate($request, [
            'email' => 'required|string',
            'password' => 'required|string',
        ]);

        if (auth()->guard('admin')->attempt($request->only('email', 'password'), $request->remember)) {
            return redirect()->intended('admin/dashboard');
        } else {
            return redirect('login')->with('error', 'Login failed')->withInput();
        }
    }

    public function changePasswordNow(Request $request)
    {
        $validator = $this->validate($request, [
            'email' => 'required|string',
            'old_password' => 'required|string',
            'new_password' => 'required|string',
        ]);
        $validate = User::where(['email' => $request->email, 'password' => $request->old_password])->first();
        if (!empty($validate)) {
            $validate->password = $request->new_password;
            $validate->save();

            return redirect()->back()->with('success', 'Password Successfully Changed.');
        } else {
            return redirect()->back()->with('error', 'Email or Password doest not match.')->withInput();
        }
    }

    public function changePassword()
    {
        return view('admin.auth.changepassword');
    }

    public function logout()
    {
        auth()->guard('admin')->logout();

        return redirect()->route('login');
    }
}
